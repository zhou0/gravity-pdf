<?php

namespace GFPDF\Templates\Config;

use GFPDF\Helper\Helper_Interface_Config;
use GFPDF\Helper\Helper_Interface_Setup_TearDown;
use GFPDF\Helper\Helper_QueryPath;

use GPDFAPI;

/**
 * Cellulose configuration file
 *
 * @package     Gravity PDF
 * @copyright   Copyright (c) 2018, Blue Liquid Designs
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 *
 */

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*
    This file is part of Gravity PDF.

    Gravity PDF – Copyright (C) 2018, Blue Liquid Designs

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

class Gpdf_Cellulose implements Helper_Interface_Config, Helper_Interface_Setup_TearDown {

	/**
	 * @var array
	 *
	 * @since 1.2
	 */
	protected $settings;

	/**
	 * @var array
	 *
	 * @since 1.2
	 */
	protected $form;

	/**
	 * @var array
	 *
	 * @since 1.2
	 */
	protected $entry;

	/**
	 * @param array $form
	 * @param array $entry
	 * @param array $settings
	 *
	 * @since 1.2
	 */
	public function setup_info( $form, $entry, $settings ) {
		$this->form     = $form;
		$this->entry    = $entry;
		$this->settings = $settings;
	}

	/**
	 * Runs once when the template is initially installed
	 *
	 * Install the Google Font Lato if it doesn't already exist for use with this PDF template
	 *
	 * @since 1.0
	 */
	public function setUp() {
		$font_data = [
			'font_name'   => 'Arimo',
			'regular'     => __DIR__ . '/../install/gpdf-cellulose/font-arimo/Arimo-Regular.ttf',
			'italics'     => __DIR__ . '/../install/gpdf-cellulose/font-arimo/Arimo-Italic.ttf',
			'bold'        => __DIR__ . '/../install/gpdf-cellulose/font-arimo/Arimo-Bold.ttf',
			'bolditalics' => __DIR__ . '/../install/gpdf-cellulose/font-arimo/Arimo-BoldItalic.ttf',
		];

		GPDFAPI::add_pdf_font( $font_data );
	}

	/**
	 * Runs once when the template is deleted
	 *
	 * Clean up additional directories
	 *
	 * @since 1.0
	 */
	public function tearDown() {
		$misc = GPDFAPI::get_misc_class();

		/* Cleanup files */
		$misc->rmdir( __DIR__ . '/../install/gpdf-cellulose' );
	}

	/**
	 * Return the templates configuration structure which control what extra fields will be shown in the "Template" tab when configuring a form's PDF.
	 *
	 * The fields key is based on our \GFPDF\Helper\Helper_Abstract_Options Settings API
	 *
	 * See the Helper_Options_Fields::register_settings() method for the exact fields that can be passed in
	 *
	 * @return array The array, split into core components and custom fields
	 *
	 * @since 1.0
	 */
	public function configuration() {
		return [
			/* Enable core fields */
			'core' => [
				'show_page_names'      => true,
				'show_html'            => true,
				'show_section_content' => true,
				'enable_conditional'   => true,
				'show_empty'           => true,
			],

			'fields' => [
				'pdf_main_heading' => [
					'id'         => 'pdf_main_heading',
					'name'       => esc_html__( 'Main Heading', 'gravity-forms-pdf-extended' ),
					'type'       => 'text',
					'std'        => '',
					'inputClass' => 'merge-tag-support mt-hide_all_fields',
					'desc'       => esc_html__( "Adjust your PDF's main heading. Leave blank to disable.", 'gravity-forms-pdf-extended' ),
				],

				'cell_logo' => [
					'id'   => 'cell_logo',
					'name' => esc_html__( 'Logo / Image', 'gravity-forms-pdf-extended' ),
					'type' => 'upload',
					'desc' => esc_html__( 'The logo / image to include at the top-left of page 1. An image 500px wide is suitable in most cases.', 'gravity-forms-pdf-extended' ),
				],

				'cell_border_colour' => [
					'id'    => 'cell_border_colour',
					'name'  => esc_html__( 'Cell Border Color', 'gravity-forms-pdf-extended' ),
					'type'  => 'color',
					'std'   => '#d4d4d4',
					'desc'  => esc_html__( 'Set the cell border color for the field label and user response.', 'gravity-forms-pdf-extended' ),
					'class' => 'gfpdf_font_colour',
				],

				'cell_hide_border' => [
					'id'   => 'cell_hide_border',
					'name' => esc_html__( 'Cell Border', 'gravity-forms-pdf-extended' ),
					'type' => 'checkbox',
					'desc' => esc_html__( 'Hide Borders', 'gravity-forms-pdf-extended' ) . '<br>' . esc_html__( 'When selected the PDF will not show any borders around the field label or user response.', 'gravity-forms-pdf-extended' ),
				],

				'cell_first_page_header' => [
					'id'   => 'cell_first_page_header',
					'name' => esc_html__( 'First Page Header', 'gravity-forms-pdf-extended' ),
					'type' => 'rich_editor',
					'desc' => esc_html__( 'This content will be displayed at the top-right of page 1.', 'gravity-forms-pdf-extended' ),
					'inputClass' => 'merge-tag-support mt-wp_editor mt-manual_position mt-position-right mt-hide_all_fields',
				],

				'cell_footer' => [
					'id'   => 'cell_footer',
					'name' => esc_html__( 'Footer', 'gravity-forms-pdf-extended' ),
					'type' => 'rich_editor',
					'desc' => esc_html__( 'This content will be displayed at the bottom-left of all pages.', 'gravity-forms-pdf-extended' ),
					'inputClass' => 'merge-tag-support mt-wp_editor mt-manual_position mt-position-right mt-hide_all_fields',
				],

				'cell_hide_page_numbers' => [
					'id'   => 'cell_hide_page_numbers',
					'name' => esc_html__( 'Page Numbers', 'gravity-forms-pdf-extended' ),
					'type' => 'checkbox',
					'desc' => esc_html__( 'Hide Page Numbering', 'gravity-forms-pdf-extended' ) . '<br>' . esc_html__( 'When selected, the PDF will not show the current page number in the bottom-right corner of the document.', 'gravity-forms-pdf-extended' ),
				],

				'cell_break1' => [
					'id'   => 'cell_break1',
					'type' => 'descriptive_text',
					'desc' => '<hr>',
				],
			],
		];
	}

	/**
	 * Add actions / filters needed to correctly display this PDF
	 *
	 * @since 1.0
	 */
	public function add_actions_and_filters() {
		add_action( 'gfpdf_pre_html_fields', [ $this, 'pre_fields_html' ], 10 );
		add_action( 'gfpdf_post_html_fields', [ $this, 'post_fields_html' ], 10 );
		add_filter( 'gfpdf_pdf_form_title_html', [ $this, 'form_title_html' ], 10 );
		add_filter( 'gfpdf_field_section_break_html', [ $this, 'section_break_html' ], 10, 7 );
		add_filter( 'gfpdf_field_page_name_html', [ $this, 'page_name_html' ], 10, 3 );
		add_filter( 'gfpdf_field_html_value', [ $this, 'default_field_html' ], 10, 7 );
		add_filter( 'gfpdf_field_product_value', [ $this, 'default_field_product' ], 10 );
	}

	/**
	 * Cleanup actions / filters used to display this PDF
	 *
	 * @since 1.0
	 */
	public function remove_actions_and_filters() {
		remove_action( 'gfpdf_pre_html_fields', [ $this, 'pre_fields_html' ], 10 );
		remove_action( 'gfpdf_post_html_fields', [ $this, 'post_fields_html' ], 10 );
		remove_filter( 'gfpdf_pdf_form_title_html', [ $this, 'form_title_html' ], 10 );
		remove_filter( 'gfpdf_field_section_break_html', [ $this, 'section_break_html' ], 10 );
		remove_filter( 'gfpdf_field_page_name_html', [ $this, 'page_name_html' ], 10 );
		remove_filter( 'gfpdf_field_html_value', [ $this, 'default_field_html' ], 10 );
		remove_filter( 'gfpdf_field_product_value', [ $this, 'default_field_product' ], 10 );
	}

	/**
	 * Output opening table tag before fields are rendered
	 *
	 * @return string
	 *
	 * @since 1.0
	 */
	public function pre_fields_html() {
		echo '<table autosize="1" id="table-wrapper">';
	}

	/**
	 * Output closing table tag before fields are rendered
	 *
	 * @return string
	 *
	 * @since 1.0
	 */
	public function post_fields_html() {
		echo '</table>';
	}

	/**
	 * Closes the current table, adds a pagebreak tag and then opens it again
	 *
	 * @since 1.1
	 */
	public function add_pagebreak() {
		$this->post_fields_html();
		echo '<pagebreak />';
		$this->pre_fields_html();
	}

	/**
	 * Output form title in a new table row
	 *
	 * @return string
	 *
	 * @since 1.0
	 */
	public function form_title_html( $html ) {
		$gform = GPDFAPI::get_form_class();

		$form_title = ( isset( $this->settings['pdf_main_heading'] ) ) ? $this->settings['pdf_main_heading'] : '';

		/* Backwards compatibility for when the PDF is upgraded but the settings haven't been saved */
		if ( isset( $this->settings['show_form_title'] ) && $this->settings['show_form_title'] == 'Yes' ) {
			$form_title = '{form_title}';
		}

		$form_title = $gform->process_tags( $form_title, $this->form, $this->entry );

		ob_start();

		if ( strlen( $form_title ) > 0 ):
			?>
            <tr id="form_title">
                <th colspan="2"><?php echo $form_title; ?></th>
            </tr>
		<?php
		endif;

		return ob_get_clean();
	}

	/**
	 * Output section title and description in a new table row
	 *
	 * @return string
	 *
	 * @since 1.0
	 */
	public function section_break_html( $html, $title, $description, $show_description, $field, $form, $entry ) {
		ob_start();

		/* Add pagebreak support */
		if ( stripos( $field->cssClass, 'pagebreak' ) !== false ) {
			$this->add_pagebreak();
		}
		?>
        <tr id="field-<?php echo $field->id; ?>"
            class="gfpdf-section-title gfpdf-field">
            <th colspan="2"><?php echo $title; ?></th>
        </tr>

		<?php if ( ! empty( $show_description ) && strlen( $description ) > 0 ): ?>
            <tr id="field-<?php echo $field->id; ?>-desc"
                class="gfpdf-section-description gfpdf-field">
                <td colspan="2"><?php echo $description; ?></td>
            </tr>
		<?php endif;

		return ob_get_clean();
	}

	/**
	 * Output page title in a new table row
	 *
	 * @return string
	 *
	 * @since 1.0
	 */
	public function page_name_html( $html, $page, $form ) {
		ob_start();
		?>
        <tr class="gfpdf-page gfpdf-field">
            <th colspan="2"><?php echo $form['pagination']['pages'][ $page ]; ?></th>
        </tr>
		<?php

		return ob_get_clean();
	}

	/**
	 * Output all normal fields in a table row
	 *
	 * @return string
	 *
	 * @since 1.0
	 */
	public function default_field_html( $html, $value, $show_label, $label, $field, $form, $entry ) {
		ob_start();

		/* Add pagebreak support */
		if ( stripos( $field->cssClass, 'pagebreak' ) !== false ) {
			$this->add_pagebreak();
		}

		$disable_label = ( isset( $this->settings['field_label_display'] ) && $this->settings['field_label_display'] == 'No Label' ) ? true : false;
		?>
        <tr id="field-<?php echo $field->id; ?>"
            class="gfpdf-<?php echo $field->type; ?> gfpdf-field <?php echo $field->cssClass; ?>">

	        <?php if ( ! $disable_label ): ?>
		        <td class="label"><?php echo $label; ?></td>
	        <?php endif; ?>

	        <td colspan="<?= $disable_label ? '2' : '1' ?>" class="value"><?php echo $value; ?></td>
        </tr>
		<?php

		return ob_get_clean();
	}

	/**
	 * Output the product table
	 *
	 * @param $html
	 *
	 * @return string
	 *
	 * @since 1.4
	 */
	public function default_field_product( $html ) {
		ob_start();

		$disable_label = ( isset( $this->settings['field_label_display'] ) && $this->settings['field_label_display'] == 'No Label' ) ? true : false;

		?>
		<tr id="field-product-table" class="gfpdf-field">
			<td colspan="<?= $disable_label ? '1' : '2' ?>">
				<?= $html ?>
			</td>
		</tr>
		<?php

		return ob_get_clean();
	}

	/**
     * Add support for Core Booster Show All Options field
     *
	 * @param string $html
	 *
	 * @return string
     *
     * @since 1.3
	 */
	public function replace_show_all_options_field( $html ) {
		try {
			$qp  = new Helper_QueryPath();
			$qpo = $qp->html5( $html );

			/* Replace our Show All Fields list markup with DIVs instead */
			foreach ( $qpo->find( 'ul[class*="-show-all-options"]' ) as $element ) {
				$element->replaceWith(
					str_replace( 'li', 'div', $element->innerHTML5() ) . ' '
				);
			}

			$html = $qpo->top( 'html' )->innerHTML5();
		} catch ( Exception $e ) {
			/* Do nothing */
		}

		return $html;
	}

	/**
     * Add direct classes to each HTML node to better target with CSS for Mpdf
     *
	 * @param string $html
	 *
	 * @return string
     *
     * @since 1.3
	 */
	public function add_header_footer_padding( $html ) {
		$qp  = new Helper_QueryPath();
		$dom = $qp->html5( $html );

		/* A recursive function that loops through the DOM tree */
		$traverseTree = function( &$dom ) use ( &$traverseTree ) {
			$children = $dom->children();

			foreach ( $children as $elm ) {
				$traverseTree( $elm );
			}

			$node = $dom->get( 0 );
			$node_name = ( $node !== null ) ? $node->nodeName : '';

			/* Wrap all pargraph tags with tables so we can add padding */
			if ( 'p' == $node_name ) {
				$dom->wrap( '<table class="header-footer-paragraph"><tr><td></td></tr></table>' );
			}
		};

		/* Traverse the entire tree */
		$traverseTree( $dom );

		/* Return the newly-formatted HTML */
		return $dom->top( 'html' )->innerHTML5();

        return $html;
	}
}