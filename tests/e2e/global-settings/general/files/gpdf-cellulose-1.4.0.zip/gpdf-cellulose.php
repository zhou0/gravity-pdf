<?php

/**
 * Template Name: Cellulose
 * Version: 1.4.0
 * Description: Cellulose displays the submitted user information in a tabular format – similar to Microsoft Excel. Customizations include toggling the borders on and off and changing the border color.
 * Author: Gravity PDF
 * Author URI: https://gravitypdf.com
 * Group: Universal (Premium)
 * License: GPLv2
 * Required PDF Version: 4.1.0-beta1
 * Tags: Border Color, Table, Grid, Form Title, HTML Fields, Page Fields, Section Description, Empty Fields
 */

/* Prevent direct access to the template */
if ( ! class_exists( 'GFForms' ) ) {
	return;
}

/**
 * All Gravity PDF 4.x templates have access to the following variables:
 *
 * $form (The current Gravity Form array)
 * $entry (The raw entry data)
 * $form_data (The processed entry data stored in an array)
 * $settings (the current PDF configuration)
 * $fields (an array of Gravity Form fields which can be accessed with their ID number)
 * $config (The initialised template config class – /config/rubix.php)
 * $gfpdf (the main Gravity PDF object containing all our helper classes)
 * $args (contains an array of all variables - the ones being described right now - passed to the template)
 */

$config->setup_info( $form, $entry, $settings );

/*
* Load our core-specific styles from our PDF settings which will be passed to the PDF template $config array
 */
$show_page_names      = ( ! empty( $settings['show_page_names'] ) && $settings['show_page_names'] == 'Yes' ) ? true : false;
$show_html            = ( ! empty( $settings['show_html'] ) && $settings['show_html'] == 'Yes' ) ? true : false;
$show_section_content = ( ! empty( $settings['show_section_content'] ) && $settings['show_section_content'] == 'Yes' ) ? true : false;
$enable_conditional   = ( ! empty( $settings['enable_conditional'] ) && $settings['enable_conditional'] == 'Yes' ) ? true : false;
$show_empty           = ( ! empty( $settings['show_empty'] ) && $settings['show_empty'] == 'Yes' ) ? true : false;

/*
 * Load our template-specific apperance settings
 */
$misc  = GPDFAPI::get_misc_class();
$gform = GPDFAPI::get_form_class();

$logo                      = ( ! empty( $settings['cell_logo'] ) ) ? $misc->convert_url_to_path( $settings['cell_logo'] ) : '';
$hide_borders              = ( isset( $settings['cell_hide_border'] ) ) ? true : false;
$cell_border_color         = ( isset( $settings['cell_border_colour'] ) ) ? $settings['cell_border_colour'] : '#d4d4d4';
$hide_page_numbering       = ( isset( $settings['cell_hide_page_numbers'] ) ) ? $settings['cell_hide_page_numbers'] : false;
$first_page_header         = ( isset( $settings['cell_first_page_header'] ) ) ? $misc->fix_header_footer( $gform->process_tags( $settings['cell_first_page_header'], $form, $entry ) ) : '';
$footer                    = ( isset( $settings['cell_footer'] ) ) ? $misc->fix_header_footer( $gform->process_tags(  $settings['cell_footer'], $form, $entry ) ) : '';
$contrast                  = $misc->get_background_and_border_contrast( $cell_border_color );
$title_background_color    = $contrast['background'];
$title_font_color          = $misc->get_contrast( $title_background_color );
$contrast                  = $misc->get_background_and_border_contrast( '#FFF' );
$contrast_background_color = $contrast['background'];
$contrast_border_color     = $contrast['border'];

/*
 * Set up our configuration array to control what is and is not shown in the generated PDF
 *
 * @var array
 */
$html_config = [
	'settings' => $settings,
	'meta'     => [
		'echo'                     => false, /* whether to output the HTML or return it */
		'exclude'                  => true, /* whether we should exclude fields with a CSS value of 'exclude'. Default to true */
		'empty'                    => $show_empty, /* whether to show empty fields or not. Default is false */
		'conditional'              => $enable_conditional, /* whether we should skip fields hidden with conditional logic. Default to true. */
		'show_title'               => true, /* whether we should show the form title. Default to true */
		'section_content'          => $show_section_content, /* whether we should include a section breaks content. Default to false */
		'page_names'               => $show_page_names, /* whether we should show the form's page names. Default to false */
		'html_field'               => $show_html, /* whether we should show the form's html fields. Default to false */
		'individual_products'      => true, /* Whether to show individual fields in the entry. Default to false - they are grouped together at the end of the form */
		'enable_css_ready_classes' => false, /* Whether to enable or disable Gravity Forms CSS Ready Class support in your PDF */
	],
];

?>

<style>

    /*
     * Page Styles
     */
    <?php if( ( $logo && strlen( $logo ) > 0 ) || strlen($first_page_header) ): ?>
        @page :first {
            margin-top: 5mm;
        }
    <?php endif; ?>

    @page {
        margin-footer: 6mm;
        footer: html_Footer;
    }

    /*
     * Header / Footer
     */
    .header td,
    .footer td {
        border: none;
        vertical-align: bottom;
    }

    .header {
        margin-bottom: 2.5mm;
    }

    .header-footer-paragraph td {
        padding-top: 2mm;
    }

    /*
	 * Quiz Style Support
	 */
    .gquiz-correct-choice {
        font-weight: bold;
    }

    .gf-quiz-img {
        padding-left: 5px !important;
        vertical-align: middle;
    }

    /*
	 * Survey Style Support
	 */
    .gsurvey-likert-choice-label {
        padding: 4px;
    }

    .gsurvey-likert-choice, .gsurvey-likert-choice-label {
        text-align: center;
    }

    .gsurvey-likert {
        border-collapse: collapse;
        margin: 2px 0 6px;
        padding: 0;
        width: 100%;
    }

    .gsurvey-likert, .gsurvey-likert th, .gsurvey-likert td {
        border: 1px solid <?php echo $contrast_border_color; ?>;
    }

    .gsurvey-likert th,
    .gsurvey-likert td {
        vertical-align: middle;
        padding: 6px 10px;
    }

    .gsurvey-likert th {
        background-color: <?php echo $contrast_background_color; ?>;
        font-weight: bold;
    }

    /*
	 * Terms of Service (Gravity Perks) Support
	 */
    .terms-of-service-agreement {
        padding-top: 2px;
        font-weight: bold;
    }

    .terms-of-service-tick {
        font-size: 150%;
    }

    /*
	 * Table Support
	 */
    th, td {
        vertical-align: top;
    }

    /*
	 * List Support
	 */
    ul, ol {
        margin: 0;
        padding-left: 1mm;
        padding-right: 1mm;
    }

    li {
        margin: 0;
        padding: 0;
        list-style-position: inside;
    }

    /*
     * Headings
     */
    h1, h3 {
        margin: 1.5mm 0 .5mm;
        padding: 0;
    }

    blockquote {
        margin: 10px 0;
        padding: 0 15px;
    }

    /*
     * Basic table design
     */
    td, th {
        <?php if ( ! $hide_borders ): ?>
            border: 1px solid <?php echo $cell_border_color; ?>;
        <?php endif; ?>
        padding: 1px 5px;
    }

    td.label {
        text-align: right;
        font-weight: bold;
        width: 25%;
    }

    td.value {
        <?php if ( $hide_borders ): ?>
            padding-left: 10px;
        <?php endif; ?>
    }

    /*
     * Specific field styles
     */
    #form_title th {
        background: <?php echo $title_background_color; ?>;
        color: <?php echo $title_font_color; ?>;
    }

    .gfpdf-page th {
        font-style: italic;
    }

    .gfpdf-section-description td {
        text-align: center;
    }

    /*
     * Generic Styles
     */
    a {
        color: #0000ff;
    }
</style>

<!-- Output our HTML markup -->
<htmlpagefooter name="Footer">
    <div class="footer">
        <table autosize="1">
            <tr>
                <td width="66%">
	                <?= $config->add_header_footer_padding( $footer ); ?>
                </td>

                <td align="right">
	                <?php if ( ! $hide_page_numbering ): ?>
                        {PAGENO}
	                <?php endif; ?>
                </td>
            </tr>
        </table>
</htmlpagefooter>

<?php if ( ( $logo && strlen( $logo ) > 0 ) || strlen( $first_page_header ) > 0 ): ?>
    <table autosize="1" class="header">
        <tr>
            <td id="logo" width="33%">
	            <?php if ( strlen( $logo ) > 0 ): ?>
                    <img src="<?php echo $logo; ?>" height="15mm" />
	            <?php endif; ?>
            </td>

            <td align="right">
	            <?php if ( strlen( $first_page_header ) > 0 ): ?>
		            <?= $config->add_header_footer_padding( $first_page_header ); ?>
	            <?php endif; ?>
            </td>
        </tr>
    </table>
<?php endif; ?>

<?php
/*
 * Generate our HTML markup
 *
 * Apply filters to change the markup so it is suitable for Cellulose
 */
$config->add_actions_and_filters();

$pdf = GPDFAPI::get_pdf_class();
$html = $pdf->process_html_structure( $entry, GPDFAPI::get_pdf_class( 'model' ), $html_config );

$config->remove_actions_and_filters();

/*
 * Post processing to better format Core Booster fields
 */
$html = $config->replace_show_all_options_field( $html );

echo $html;